# App CI/CD

Aplicação Flask simples com testes (pytest), CI/CD via GitHub Actions e deploy no Render.

Rodar local:
    pip install -r requirements.txt
    python app.py
    pytest
