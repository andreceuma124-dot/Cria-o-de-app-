from flask import Flask, jsonify

app = Flask(__name__)


def somar(a, b):
    return a + b


@app.route("/")
def home():
    return jsonify(mensagem="Olá! Minha aplicação com CI/CD está no ar 🚀")


@app.route("/somar/<int:a>/<int:b>")
def rota_somar(a, b):
    return jsonify(resultado=somar(a, b))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
