from app import app, somar


def test_somar():
    assert somar(2, 3) == 5


def test_home():
    resposta = app.test_client().get("/")
    assert resposta.status_code == 200
    assert "mensagem" in resposta.get_json()


def test_rota_somar():
    resposta = app.test_client().get("/somar/4/6")
    assert resposta.get_json() == {"resultado": 10}
